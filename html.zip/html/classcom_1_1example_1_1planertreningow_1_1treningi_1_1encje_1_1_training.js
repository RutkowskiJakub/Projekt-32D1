var classcom_1_1example_1_1planertreningow_1_1treningi_1_1encje_1_1_training =
[
    [ "Training", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1encje_1_1_training.html#a6b03dc6a2f63edc1d2f45afc7b89965c", null ],
    [ "Training", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1encje_1_1_training.html#ad1757a7799844a41de76ee360bafaeae", null ],
    [ "Training", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1encje_1_1_training.html#aec157d2b89cc6f5a917a2465c23e3c49", null ],
    [ "Training", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1encje_1_1_training.html#a5cbef391402603e2ffa20e2f1a3b35ee", null ],
    [ "addExercise", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1encje_1_1_training.html#ad0322e8331a4546f20e548ed800143ab", null ],
    [ "get_id", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1encje_1_1_training.html#a4bd77183f13505a272b7c7a831a20df5", null ],
    [ "getExercises", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1encje_1_1_training.html#a7fdd348b8a2676cb896bda54ee5501fe", null ],
    [ "getName", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1encje_1_1_training.html#a2bbdd4a5236ad8cd0af1525127caaa3c", null ],
    [ "removeExercise", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1encje_1_1_training.html#a6f6148d293a925e84fbd74fd8ad6254f", null ],
    [ "set_id", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1encje_1_1_training.html#ab3f043903a22dbd94bb21d8f0d9bf40d", null ],
    [ "setExercises", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1encje_1_1_training.html#ab7941df5e79940361097e518408fef8a", null ],
    [ "setName", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1encje_1_1_training.html#a1d01e41ec5fe45e526676b78b055a483", null ],
    [ "_id", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1encje_1_1_training.html#a605c3d3e42cd83152eb47401a548aae3", null ],
    [ "exercises", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1encje_1_1_training.html#a43648fbfbe308c70f6caefb4b019c912", null ],
    [ "name", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1encje_1_1_training.html#ac52695f899f058d7785f9503f2328717", null ]
];