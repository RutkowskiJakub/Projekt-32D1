var dir_616c60c245f329a860050dde72551a14 =
[
    [ "ExampleInstrumentedTest.java", "_example_instrumented_test_8java.html", [
      [ "ExampleInstrumentedTest", "classcom_1_1example_1_1planertreningow_1_1_example_instrumented_test.html", "classcom_1_1example_1_1planertreningow_1_1_example_instrumented_test" ]
    ] ]
];