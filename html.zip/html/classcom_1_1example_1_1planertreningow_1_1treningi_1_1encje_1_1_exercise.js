var classcom_1_1example_1_1planertreningow_1_1treningi_1_1encje_1_1_exercise =
[
    [ "Exercise", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1encje_1_1_exercise.html#af6ea2fc0b63ebe8c7c5ae8927c66d8d2", null ],
    [ "Exercise", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1encje_1_1_exercise.html#a5787236d4cb018d634506aa446d02f1b", null ],
    [ "Exercise", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1encje_1_1_exercise.html#af58276026ec7a3b1743a461d92986dac", null ],
    [ "Exercise", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1encje_1_1_exercise.html#aa430548b54f78e5c3e44587e6ed86ef7", null ],
    [ "addSet", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1encje_1_1_exercise.html#a9a483422212c8bad1cd7c53010e4f187", null ],
    [ "get_id", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1encje_1_1_exercise.html#a0846927c6fffff8b3e8a5f1182e49f4d", null ],
    [ "getName", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1encje_1_1_exercise.html#ae3957d6671401d70f310e9d989d80706", null ],
    [ "getSets", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1encje_1_1_exercise.html#a794185fcee8fa6a3e9059561285372ed", null ],
    [ "removeSet", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1encje_1_1_exercise.html#ae450d12604e895ad4cdeb188f7a68c4c", null ],
    [ "set_id", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1encje_1_1_exercise.html#a9dcf4d3e893ffeb28a04d1173a35c4bc", null ],
    [ "setName", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1encje_1_1_exercise.html#af3dc0318c88378633ab4eef8d4189b41", null ],
    [ "setSets", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1encje_1_1_exercise.html#afc4f94bbc6434854b62ea392c1b8ade8", null ],
    [ "_id", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1encje_1_1_exercise.html#aac0fd29414e6093870b1e4b21477c634", null ],
    [ "name", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1encje_1_1_exercise.html#a13d5d714088018b6174701486553db7c", null ],
    [ "sets", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1encje_1_1_exercise.html#abce9bedcb5ba6e5a01fba8c846492339", null ]
];