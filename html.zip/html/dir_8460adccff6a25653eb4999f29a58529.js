var dir_8460adccff6a25653eb4999f29a58529 =
[
    [ "MainActivity.java", "_main_activity_8java.html", [
      [ "MainActivity", "classcom_1_1example_1_1planertreningow_1_1_main_activity.html", "classcom_1_1example_1_1planertreningow_1_1_main_activity" ]
    ] ]
];