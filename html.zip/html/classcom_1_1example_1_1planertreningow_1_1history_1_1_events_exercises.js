var classcom_1_1example_1_1planertreningow_1_1history_1_1_events_exercises =
[
    [ "Back", "classcom_1_1example_1_1planertreningow_1_1history_1_1_events_exercises.html#a1f0f9920babd36c55811b8ee2b9b613a", null ],
    [ "checkIfExtras", "classcom_1_1example_1_1planertreningow_1_1history_1_1_events_exercises.html#a25fa6f4c53128135d3b563014731871c", null ],
    [ "onCreate", "classcom_1_1example_1_1planertreningow_1_1history_1_1_events_exercises.html#a57d3bee98b449a798d9fbd0a580f92f5", null ],
    [ "refreshList", "classcom_1_1example_1_1planertreningow_1_1history_1_1_events_exercises.html#abb4181e88a66acec8a07a814c3426aee", null ],
    [ "startExercise", "classcom_1_1example_1_1planertreningow_1_1history_1_1_events_exercises.html#abb996a08474ee82a9af8d5f9dfabfe6c", null ],
    [ "events", "classcom_1_1example_1_1planertreningow_1_1history_1_1_events_exercises.html#a5aa7a7a320e1e4532831f226858ce406", null ],
    [ "training", "classcom_1_1example_1_1planertreningow_1_1history_1_1_events_exercises.html#a444ad807070a22d3d4f2ab11d0a4a03f", null ],
    [ "trainings", "classcom_1_1example_1_1planertreningow_1_1history_1_1_events_exercises.html#a56a7ba6a4af962837451d607a21d3a7e", null ]
];