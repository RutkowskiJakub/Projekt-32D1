var classcom_1_1example_1_1planertreningow_1_1history_1_1kalendarz =
[
    [ "AddEvent", "classcom_1_1example_1_1planertreningow_1_1history_1_1kalendarz.html#a741ce99a33fe74e34dbc24603d08f80b", null ],
    [ "Back", "classcom_1_1example_1_1planertreningow_1_1history_1_1kalendarz.html#afccef59a7a22bf5003f6b617c8d30f0f", null ],
    [ "checkIfExtras", "classcom_1_1example_1_1planertreningow_1_1history_1_1kalendarz.html#a0e160a8a7e606badb3368a4d1dad33de", null ],
    [ "initEvents", "classcom_1_1example_1_1planertreningow_1_1history_1_1kalendarz.html#a4aa19512f88db937ff9d40d6ef77cf2e", null ],
    [ "onCreate", "classcom_1_1example_1_1planertreningow_1_1history_1_1kalendarz.html#a918966d852c41231dc746f24eb4610d4", null ],
    [ "onItemClick", "classcom_1_1example_1_1planertreningow_1_1history_1_1kalendarz.html#aa5be57d006c83faee2e193f36039b8a1", null ],
    [ "StartExercise", "classcom_1_1example_1_1planertreningow_1_1history_1_1kalendarz.html#af6096dba60fc648a4a5078d659708dcd", null ],
    [ "calendarView", "classcom_1_1example_1_1planertreningow_1_1history_1_1kalendarz.html#a6000c3ec8c0c8827bf05e36e29677979", null ],
    [ "currentlyOn", "classcom_1_1example_1_1planertreningow_1_1history_1_1kalendarz.html#a85a524aa5362cf6771d10b8dbdfa6e7d", null ],
    [ "events", "classcom_1_1example_1_1planertreningow_1_1history_1_1kalendarz.html#ad53d9730c9a62c9d99238b75560e74af", null ],
    [ "sdf", "classcom_1_1example_1_1planertreningow_1_1history_1_1kalendarz.html#a6166bf29305cd151a6350fee8c1a21b7", null ],
    [ "trainings", "classcom_1_1example_1_1planertreningow_1_1history_1_1kalendarz.html#aa68e7ffc9ac0ba574243382c524b3e8a", null ]
];