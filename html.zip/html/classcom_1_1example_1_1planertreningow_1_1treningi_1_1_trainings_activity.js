var classcom_1_1example_1_1planertreningow_1_1treningi_1_1_trainings_activity =
[
    [ "Back", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1_trainings_activity.html#aaa6adeada8c8f965146d20062ebfdaac", null ],
    [ "checkIfExtras", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1_trainings_activity.html#ab9e9edfcd8f4ec5160940a51225a80f0", null ],
    [ "CreateExampleTraining", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1_trainings_activity.html#a9d0aa3965d7e0930add6ff7370e8323f", null ],
    [ "edit", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1_trainings_activity.html#a96963069a0cb20be5c46d9784e96ee9f", null ],
    [ "Next", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1_trainings_activity.html#adc6739c6c2465f5085ae178f7cdf2f97", null ],
    [ "onCreate", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1_trainings_activity.html#a9851f2506593c9dcae40ee8009481ca5", null ],
    [ "refreshList", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1_trainings_activity.html#aec3159bd4630bb02fdb7a4a9a28b2376", null ],
    [ "setID", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1_trainings_activity.html#aff86d9b4f23c9726d398a2b55275fc96", null ],
    [ "templates", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1_trainings_activity.html#a5ba203070783a9a405e97c5240089025", null ],
    [ "training", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1_trainings_activity.html#a13888003ee772e6c79da970b7ff77023", null ],
    [ "trainings", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1_trainings_activity.html#aa9683b11d20f84aedb939c7b381c501f", null ]
];