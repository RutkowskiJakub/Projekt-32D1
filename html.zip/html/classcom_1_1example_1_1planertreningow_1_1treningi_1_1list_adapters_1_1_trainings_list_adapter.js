var classcom_1_1example_1_1planertreningow_1_1treningi_1_1list_adapters_1_1_trainings_list_adapter =
[
    [ "TrainingsListAdapter", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1list_adapters_1_1_trainings_list_adapter.html#acb27828eb2d5eba4ea64198e1763f304", null ],
    [ "getView", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1list_adapters_1_1_trainings_list_adapter.html#a9096c4fb05e3417e0a6236837b89d0fc", null ]
];