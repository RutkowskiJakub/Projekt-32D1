var hierarchy =
[
    [ "com.example.planertreningow.ExampleInstrumentedTest", "classcom_1_1example_1_1planertreningow_1_1_example_instrumented_test.html", null ],
    [ "com.example.planertreningow.ExampleUnitTest", "classcom_1_1example_1_1planertreningow_1_1_example_unit_test.html", null ],
    [ "AppCompatActivity", null, [
      [ "com.example.planertreningow.history.AddEvent", "classcom_1_1example_1_1planertreningow_1_1history_1_1_add_event.html", null ],
      [ "com.example.planertreningow.history.EventsExercises", "classcom_1_1example_1_1planertreningow_1_1history_1_1_events_exercises.html", null ],
      [ "com.example.planertreningow.history.Exing", "classcom_1_1example_1_1planertreningow_1_1history_1_1_exing.html", null ],
      [ "com.example.planertreningow.history.kalendarz", "classcom_1_1example_1_1planertreningow_1_1history_1_1kalendarz.html", null ],
      [ "com.example.planertreningow.MainActivity", "classcom_1_1example_1_1planertreningow_1_1_main_activity.html", null ],
      [ "com.example.planertreningow.szablony.AddTemplateActivity", "classcom_1_1example_1_1planertreningow_1_1szablony_1_1_add_template_activity.html", null ],
      [ "com.example.planertreningow.szablony.ExerciseTemplateActivity", "classcom_1_1example_1_1planertreningow_1_1szablony_1_1_exercise_template_activity.html", null ],
      [ "com.example.planertreningow.szablony.TemplateActivity", "classcom_1_1example_1_1planertreningow_1_1szablony_1_1_template_activity.html", null ],
      [ "com.example.planertreningow.szablony.TemplatesActivity", "classcom_1_1example_1_1planertreningow_1_1szablony_1_1_templates_activity.html", null ],
      [ "com.example.planertreningow.treningi.AddTrainingActivity", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1_add_training_activity.html", null ],
      [ "com.example.planertreningow.treningi.ExerciseActivity", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1_exercise_activity.html", null ],
      [ "com.example.planertreningow.treningi.TrainingActivity", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1_training_activity.html", null ],
      [ "com.example.planertreningow.treningi.TrainingsActivity", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1_trainings_activity.html", null ]
    ] ],
    [ "ArrayAdapter", null, [
      [ "com.example.planertreningow.treningi.listAdapters.ExerciseListAdapter", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1list_adapters_1_1_exercise_list_adapter.html", null ],
      [ "com.example.planertreningow.treningi.listAdapters.TrainingsListAdapter", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1list_adapters_1_1_trainings_list_adapter.html", null ]
    ] ],
    [ "Serializable", null, [
      [ "com.example.planertreningow.history.Event", "classcom_1_1example_1_1planertreningow_1_1history_1_1_event.html", null ],
      [ "com.example.planertreningow.treningi.encje.Exercise", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1encje_1_1_exercise.html", null ],
      [ "com.example.planertreningow.treningi.encje.Set", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1encje_1_1_set.html", null ],
      [ "com.example.planertreningow.treningi.encje.Training", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1encje_1_1_training.html", null ]
    ] ]
];