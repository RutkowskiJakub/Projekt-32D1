var dir_016fc583d39985d3abfe5cdeb9cec45d =
[
    [ "history", "dir_ee65944af42f0d24d2ec81597c21bf58.html", "dir_ee65944af42f0d24d2ec81597c21bf58" ],
    [ "szablony", "dir_ff870ba7083afc41ffc549d610009ddb.html", "dir_ff870ba7083afc41ffc549d610009ddb" ],
    [ "treningi", "dir_a5b31c878fad0843d242ae7cb8a1321d.html", "dir_a5b31c878fad0843d242ae7cb8a1321d" ],
    [ "MainActivity.java", "_main_activity_8java.html", [
      [ "MainActivity", "classcom_1_1example_1_1planertreningow_1_1_main_activity.html", "classcom_1_1example_1_1planertreningow_1_1_main_activity" ]
    ] ]
];