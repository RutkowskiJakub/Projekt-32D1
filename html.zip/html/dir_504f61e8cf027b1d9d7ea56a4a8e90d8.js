var dir_504f61e8cf027b1d9d7ea56a4a8e90d8 =
[
    [ "ExerciseListAdapter.java", "_exercise_list_adapter_8java.html", [
      [ "ExerciseListAdapter", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1list_adapters_1_1_exercise_list_adapter.html", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1list_adapters_1_1_exercise_list_adapter" ]
    ] ],
    [ "TrainingsListAdapter.java", "_trainings_list_adapter_8java.html", [
      [ "TrainingsListAdapter", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1list_adapters_1_1_trainings_list_adapter.html", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1list_adapters_1_1_trainings_list_adapter" ]
    ] ]
];