var classcom_1_1example_1_1planertreningow_1_1szablony_1_1_add_template_activity =
[
    [ "Back", "classcom_1_1example_1_1planertreningow_1_1szablony_1_1_add_template_activity.html#a0af238415ea2e00c938de6ef84e5bbeb", null ],
    [ "checkIfExtras", "classcom_1_1example_1_1planertreningow_1_1szablony_1_1_add_template_activity.html#aace81431d89989d4e79efe98143b7e71", null ],
    [ "Delete", "classcom_1_1example_1_1planertreningow_1_1szablony_1_1_add_template_activity.html#ab778c51fc6a77431a8c042cd13c34778", null ],
    [ "Next", "classcom_1_1example_1_1planertreningow_1_1szablony_1_1_add_template_activity.html#a5e051fc8d2d3501cf34c5fc1971fa065", null ],
    [ "onCreate", "classcom_1_1example_1_1planertreningow_1_1szablony_1_1_add_template_activity.html#a7089cccc2589be6c35fe073eea40d002", null ],
    [ "Save", "classcom_1_1example_1_1planertreningow_1_1szablony_1_1_add_template_activity.html#a43b45f291e58ce12199d18fccd9fb5d8", null ],
    [ "setID", "classcom_1_1example_1_1planertreningow_1_1szablony_1_1_add_template_activity.html#a4df0b385d532466abc24d8abed35fdd9", null ],
    [ "deleteButton", "classcom_1_1example_1_1planertreningow_1_1szablony_1_1_add_template_activity.html#a0763aafd65be32376b29c70ab662b2de", null ],
    [ "editing", "classcom_1_1example_1_1planertreningow_1_1szablony_1_1_add_template_activity.html#aacc83b1efbac45c6d9b88145915aa317", null ],
    [ "saveButton", "classcom_1_1example_1_1planertreningow_1_1szablony_1_1_add_template_activity.html#a969dfc9df8c103644aaf07362ef6eac8", null ],
    [ "template", "classcom_1_1example_1_1planertreningow_1_1szablony_1_1_add_template_activity.html#a9b115526980397f4048668db0b99be88", null ],
    [ "templates", "classcom_1_1example_1_1planertreningow_1_1szablony_1_1_add_template_activity.html#ac5b279312e9b27ce92dc5d1a1e4110b0", null ],
    [ "trainings", "classcom_1_1example_1_1planertreningow_1_1szablony_1_1_add_template_activity.html#a10e4f057ad26eeaa41b0dca430f70ade", null ]
];