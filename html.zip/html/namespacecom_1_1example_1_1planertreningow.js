var namespacecom_1_1example_1_1planertreningow =
[
    [ "history", "namespacecom_1_1example_1_1planertreningow_1_1history.html", "namespacecom_1_1example_1_1planertreningow_1_1history" ],
    [ "szablony", "namespacecom_1_1example_1_1planertreningow_1_1szablony.html", "namespacecom_1_1example_1_1planertreningow_1_1szablony" ],
    [ "treningi", "namespacecom_1_1example_1_1planertreningow_1_1treningi.html", "namespacecom_1_1example_1_1planertreningow_1_1treningi" ],
    [ "ExampleInstrumentedTest", "classcom_1_1example_1_1planertreningow_1_1_example_instrumented_test.html", "classcom_1_1example_1_1planertreningow_1_1_example_instrumented_test" ],
    [ "ExampleUnitTest", "classcom_1_1example_1_1planertreningow_1_1_example_unit_test.html", "classcom_1_1example_1_1planertreningow_1_1_example_unit_test" ],
    [ "MainActivity", "classcom_1_1example_1_1planertreningow_1_1_main_activity.html", "classcom_1_1example_1_1planertreningow_1_1_main_activity" ]
];