var dir_b55e05ba33428104e3eb74ee3b1693ae =
[
    [ "Exercise.java", "_exercise_8java.html", [
      [ "Exercise", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1encje_1_1_exercise.html", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1encje_1_1_exercise" ]
    ] ],
    [ "Set.java", "_set_8java.html", [
      [ "Set", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1encje_1_1_set.html", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1encje_1_1_set" ]
    ] ],
    [ "Training.java", "_training_8java.html", [
      [ "Training", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1encje_1_1_training.html", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1encje_1_1_training" ]
    ] ]
];