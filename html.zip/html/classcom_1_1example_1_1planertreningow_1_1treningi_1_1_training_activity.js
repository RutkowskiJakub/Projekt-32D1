var classcom_1_1example_1_1planertreningow_1_1treningi_1_1_training_activity =
[
    [ "Back", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1_training_activity.html#a2af798239f21620d4ac1d053863cdf97", null ],
    [ "checkIfExtras", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1_training_activity.html#a68f995bce6b07fc543eff8f804cb2376", null ],
    [ "deleteFromList", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1_training_activity.html#abe13184c4af087a6525f385c8d027994", null ],
    [ "edit", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1_training_activity.html#a7ca8592705c1ef0a2625b7ea9bb73a0b", null ],
    [ "getExercises", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1_training_activity.html#a2e9795384c139afff011fb4d5ffd0409", null ],
    [ "Next", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1_training_activity.html#a85aa110345868a57495543733726e41d", null ],
    [ "onCreate", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1_training_activity.html#ab193d198787177bbc765f2c76ceb2ff5", null ],
    [ "refreshExercise", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1_training_activity.html#aa6ee05cd24abd581b81457c9e65bde94", null ],
    [ "Save", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1_training_activity.html#a03953a9d16d0c825514bc80672522a80", null ],
    [ "editing", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1_training_activity.html#a1356e898cedec2b2aaf98d8158833f24", null ],
    [ "exercise", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1_training_activity.html#ac3f287b6874ab2a3a4b6ab41bdc87571", null ],
    [ "exercises", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1_training_activity.html#ad00bb756a9a2f4fd0b87251375ac4993", null ],
    [ "imageButton", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1_training_activity.html#a391c47f68b2f05eb12156253e8bb4fd2", null ],
    [ "templates", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1_training_activity.html#a734251a0cb5f1e7b8afc85be14a74e4d", null ],
    [ "training", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1_training_activity.html#aa7c12a23b611620117e848cf8a190385", null ],
    [ "trainings", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1_training_activity.html#a579d9d94a40024d14644d5d3231ca767", null ]
];