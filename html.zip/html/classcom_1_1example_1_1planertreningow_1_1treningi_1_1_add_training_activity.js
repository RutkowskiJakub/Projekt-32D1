var classcom_1_1example_1_1planertreningow_1_1treningi_1_1_add_training_activity =
[
    [ "Back", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1_add_training_activity.html#aeb1e4946a7084c2bc4c3606d979bf409", null ],
    [ "checkIfExtras", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1_add_training_activity.html#ad73ba4d468a780ea48ea6cc3ba6e7b65", null ],
    [ "Delete", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1_add_training_activity.html#acff07f4258c006c24efeb8862db3ed50", null ],
    [ "Next", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1_add_training_activity.html#a3d7d8eede004b2783a58e8e753e9bb29", null ],
    [ "onCreate", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1_add_training_activity.html#a80612e03cb4679a91916e01f27d71ee5", null ],
    [ "Save", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1_add_training_activity.html#a34571dfff99f30b0c552d836fc954174", null ],
    [ "setID", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1_add_training_activity.html#ab8c9b899c9339b0af4c076318d060ece", null ],
    [ "deleteButton", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1_add_training_activity.html#ad85dc3ec1c76e2d478705e8448a95226", null ],
    [ "editing", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1_add_training_activity.html#a945539d24ea58f9bc7463cb5d54e666b", null ],
    [ "saveButton", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1_add_training_activity.html#a4860ff5439bdaa2ca386c8866187b600", null ],
    [ "templates", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1_add_training_activity.html#aa810a396fbfbb3c245c2a98396d56f68", null ],
    [ "training", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1_add_training_activity.html#a092ab35911a879b7ce78aab1ef01197b", null ],
    [ "trainings", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1_add_training_activity.html#a4ee2312f809296002c9d83aacfecb500", null ]
];