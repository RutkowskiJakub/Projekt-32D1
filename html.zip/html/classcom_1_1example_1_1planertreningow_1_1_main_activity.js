var classcom_1_1example_1_1planertreningow_1_1_main_activity =
[
    [ "checkIfExtras", "classcom_1_1example_1_1planertreningow_1_1_main_activity.html#a4b7d0f1d0b4ffb7bce3c93a1ebe976a3", null ],
    [ "NavigateHistoryActivity", "classcom_1_1example_1_1planertreningow_1_1_main_activity.html#a638dda826e7b24c3100b3ec5308314a1", null ],
    [ "NavigateSettings", "classcom_1_1example_1_1planertreningow_1_1_main_activity.html#ae46c8d387c7d43228441785af24659de", null ],
    [ "NavigateTemplatesActivity", "classcom_1_1example_1_1planertreningow_1_1_main_activity.html#a7d0feef60ce7b60abb5de9a478eee626", null ],
    [ "NavigateTrainingActivity", "classcom_1_1example_1_1planertreningow_1_1_main_activity.html#aceb8610c016ea1186427d7b8f09be5a7", null ],
    [ "onCreate", "classcom_1_1example_1_1planertreningow_1_1_main_activity.html#ab285a5789c575a69aa8271a903dae8ba", null ],
    [ "onStart", "classcom_1_1example_1_1planertreningow_1_1_main_activity.html#aaf4d2cbf52c787ea34d507c49c053339", null ],
    [ "parseAndLoad", "classcom_1_1example_1_1planertreningow_1_1_main_activity.html#ac6b030da666b35c15b7a31a2ad0a4d05", null ],
    [ "parseAndSave", "classcom_1_1example_1_1planertreningow_1_1_main_activity.html#af496dd00ee60419c540e0005d0834b7d", null ],
    [ "events", "classcom_1_1example_1_1planertreningow_1_1_main_activity.html#aa15f69182f914ded0d4fe021e9c6f622", null ],
    [ "templates", "classcom_1_1example_1_1planertreningow_1_1_main_activity.html#a862b42a0a80ff6deb153b338860581dc", null ],
    [ "trainings", "classcom_1_1example_1_1planertreningow_1_1_main_activity.html#a2bfeb95ea9b994419dfbd3168dd0497f", null ]
];