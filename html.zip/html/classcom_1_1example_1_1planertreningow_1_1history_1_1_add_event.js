var classcom_1_1example_1_1planertreningow_1_1history_1_1_add_event =
[
    [ "add", "classcom_1_1example_1_1planertreningow_1_1history_1_1_add_event.html#a480e873b5f15dcad6f1eec689515721e", null ],
    [ "Back", "classcom_1_1example_1_1planertreningow_1_1history_1_1_add_event.html#a674da4d2073cfded28f062df2f9b42a8", null ],
    [ "checkIfExtras", "classcom_1_1example_1_1planertreningow_1_1history_1_1_add_event.html#ae49d6089fe585f569444542900dee415", null ],
    [ "onCreate", "classcom_1_1example_1_1planertreningow_1_1history_1_1_add_event.html#a9d8654cb5a2ce06f52aebde6126fb3df", null ],
    [ "refreshList", "classcom_1_1example_1_1planertreningow_1_1history_1_1_add_event.html#adc44a471e0454a4121d6b92d60e74512", null ],
    [ "event", "classcom_1_1example_1_1planertreningow_1_1history_1_1_add_event.html#a9ba34cfbd1701de515dba882e7000316", null ],
    [ "events", "classcom_1_1example_1_1planertreningow_1_1history_1_1_add_event.html#a12834d8477cff6ad3bd1df25bcb180b7", null ],
    [ "trainings", "classcom_1_1example_1_1planertreningow_1_1history_1_1_add_event.html#ae1534ec2a2644554b448d752e940a734", null ]
];