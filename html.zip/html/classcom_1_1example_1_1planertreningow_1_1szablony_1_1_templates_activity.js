var classcom_1_1example_1_1planertreningow_1_1szablony_1_1_templates_activity =
[
    [ "addToTrainings", "classcom_1_1example_1_1planertreningow_1_1szablony_1_1_templates_activity.html#a2dac78d3b0b757080624d447cd0a29e5", null ],
    [ "Back", "classcom_1_1example_1_1planertreningow_1_1szablony_1_1_templates_activity.html#aeb33c401a7e363be5dd767f1191b30bf", null ],
    [ "checkIfExtras", "classcom_1_1example_1_1planertreningow_1_1szablony_1_1_templates_activity.html#aca6e56fd1611b63e70d5c5d96ecaa9d5", null ],
    [ "edit", "classcom_1_1example_1_1planertreningow_1_1szablony_1_1_templates_activity.html#ab3c59bd83cfe5872c446a91c356a4e97", null ],
    [ "Next", "classcom_1_1example_1_1planertreningow_1_1szablony_1_1_templates_activity.html#aa9445571a6ed77f2a10c1afe04b80429", null ],
    [ "onCreate", "classcom_1_1example_1_1planertreningow_1_1szablony_1_1_templates_activity.html#ae658816ca556f670e6489b1c3fb7f979", null ],
    [ "refreshList", "classcom_1_1example_1_1planertreningow_1_1szablony_1_1_templates_activity.html#a946b41797ead33411389b9d44d7dc2d5", null ],
    [ "someTemplates", "classcom_1_1example_1_1planertreningow_1_1szablony_1_1_templates_activity.html#a1f2ecd9e353921580d11ec7a60fb0f74", null ],
    [ "template", "classcom_1_1example_1_1planertreningow_1_1szablony_1_1_templates_activity.html#a1bf909717883bc7c8bb6cf841319494a", null ],
    [ "templates", "classcom_1_1example_1_1planertreningow_1_1szablony_1_1_templates_activity.html#ae4cf742cd86e41238db3a07b0a4b8cbc", null ],
    [ "trainings", "classcom_1_1example_1_1planertreningow_1_1szablony_1_1_templates_activity.html#a7e6c4c7e03d82ad5ec114f974d6b1cca", null ]
];