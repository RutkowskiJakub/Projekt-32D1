var classcom_1_1example_1_1planertreningow_1_1treningi_1_1list_adapters_1_1_exercise_list_adapter =
[
    [ "ExerciseListAdapter", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1list_adapters_1_1_exercise_list_adapter.html#a0416c6a7b29a7fbf22942ad7ff360a59", null ],
    [ "getView", "classcom_1_1example_1_1planertreningow_1_1treningi_1_1list_adapters_1_1_exercise_list_adapter.html#a06731c73debd3fae701ba72c7489b8d4", null ]
];