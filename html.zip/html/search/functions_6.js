var searchData=
[
  ['initevents_201',['initEvents',['../classcom_1_1example_1_1planertreningow_1_1history_1_1kalendarz.html#a4aa19512f88db937ff9d40d6ef77cf2e',1,'com::example::planertreningow::history::kalendarz']]]
];
