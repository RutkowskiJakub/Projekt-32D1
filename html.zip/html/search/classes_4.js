var searchData=
[
  ['set_139',['Set',['../classcom_1_1example_1_1planertreningow_1_1treningi_1_1encje_1_1_set.html',1,'com::example::planertreningow::treningi::encje']]]
];
