var searchData=
[
  ['date_241',['date',['../classcom_1_1example_1_1planertreningow_1_1history_1_1_event.html#abe32035326ea1938f3671e6b03abebb8',1,'com::example::planertreningow::history::Event']]],
  ['deletebutton_242',['deleteButton',['../classcom_1_1example_1_1planertreningow_1_1szablony_1_1_add_template_activity.html#a0763aafd65be32376b29c70ab662b2de',1,'com.example.planertreningow.szablony.AddTemplateActivity.deleteButton()'],['../classcom_1_1example_1_1planertreningow_1_1treningi_1_1_add_training_activity.html#ad85dc3ec1c76e2d478705e8448a95226',1,'com.example.planertreningow.treningi.AddTrainingActivity.deleteButton()']]]
];
