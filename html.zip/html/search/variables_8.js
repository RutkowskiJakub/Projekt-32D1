var searchData=
[
  ['savebutton_253',['saveButton',['../classcom_1_1example_1_1planertreningow_1_1szablony_1_1_add_template_activity.html#a969dfc9df8c103644aaf07362ef6eac8',1,'com.example.planertreningow.szablony.AddTemplateActivity.saveButton()'],['../classcom_1_1example_1_1planertreningow_1_1treningi_1_1_add_training_activity.html#a4860ff5439bdaa2ca386c8866187b600',1,'com.example.planertreningow.treningi.AddTrainingActivity.saveButton()']]],
  ['sdf_254',['sdf',['../classcom_1_1example_1_1planertreningow_1_1history_1_1kalendarz.html#a6166bf29305cd151a6350fee8c1a21b7',1,'com::example::planertreningow::history::kalendarz']]],
  ['sets_255',['sets',['../classcom_1_1example_1_1planertreningow_1_1treningi_1_1encje_1_1_exercise.html#abce9bedcb5ba6e5a01fba8c846492339',1,'com::example::planertreningow::treningi::encje::Exercise']]]
];
