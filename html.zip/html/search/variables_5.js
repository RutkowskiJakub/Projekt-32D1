var searchData=
[
  ['name_249',['name',['../classcom_1_1example_1_1planertreningow_1_1treningi_1_1encje_1_1_exercise.html#a13d5d714088018b6174701486553db7c',1,'com.example.planertreningow.treningi.encje.Exercise.name()'],['../classcom_1_1example_1_1planertreningow_1_1treningi_1_1encje_1_1_training.html#ac52695f899f058d7785f9503f2328717',1,'com.example.planertreningow.treningi.encje.Training.name()']]]
];
