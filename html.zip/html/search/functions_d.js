var searchData=
[
  ['useappcontext_236',['useAppContext',['../classcom_1_1example_1_1planertreningow_1_1_example_instrumented_test.html#abe912ccb5cf77bc9a1ac686b74616c4b',1,'com::example::planertreningow::ExampleInstrumentedTest']]]
];
