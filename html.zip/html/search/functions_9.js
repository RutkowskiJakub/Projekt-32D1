var searchData=
[
  ['parseandload_210',['parseAndLoad',['../classcom_1_1example_1_1planertreningow_1_1_main_activity.html#ac6b030da666b35c15b7a31a2ad0a4d05',1,'com::example::planertreningow::MainActivity']]],
  ['parseandsave_211',['parseAndSave',['../classcom_1_1example_1_1planertreningow_1_1_main_activity.html#af496dd00ee60419c540e0005d0834b7d',1,'com::example::planertreningow::MainActivity']]]
];
