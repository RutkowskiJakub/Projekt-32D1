var searchData=
[
  ['mainactivity_66',['MainActivity',['../classcom_1_1example_1_1planertreningow_1_1_main_activity.html',1,'com::example::planertreningow']]],
  ['mainactivity_2ejava_67',['MainActivity.java',['../_main_activity_8java.html',1,'']]]
];
