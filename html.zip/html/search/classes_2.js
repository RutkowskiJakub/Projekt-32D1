var searchData=
[
  ['kalendarz_137',['kalendarz',['../classcom_1_1example_1_1planertreningow_1_1history_1_1kalendarz.html',1,'com::example::planertreningow::history']]]
];
