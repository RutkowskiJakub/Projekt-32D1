var searchData=
[
  ['delete_185',['Delete',['../classcom_1_1example_1_1planertreningow_1_1szablony_1_1_add_template_activity.html#ab778c51fc6a77431a8c042cd13c34778',1,'com.example.planertreningow.szablony.AddTemplateActivity.Delete()'],['../classcom_1_1example_1_1planertreningow_1_1treningi_1_1_add_training_activity.html#acff07f4258c006c24efeb8862db3ed50',1,'com.example.planertreningow.treningi.AddTrainingActivity.Delete()'],['../classcom_1_1example_1_1planertreningow_1_1szablony_1_1_template_activity.html#adc545a13471ce78d1466b94fd479a931',1,'com.example.planertreningow.szablony.TemplateActivity.delete()']]],
  ['deletefromlist_186',['deleteFromList',['../classcom_1_1example_1_1planertreningow_1_1treningi_1_1_training_activity.html#abe13184c4af087a6525f385c8d027994',1,'com::example::planertreningow::treningi::TrainingActivity']]]
];
