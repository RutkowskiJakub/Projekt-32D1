var classcom_1_1example_1_1planertreningow_1_1szablony_1_1_template_activity =
[
    [ "Back", "classcom_1_1example_1_1planertreningow_1_1szablony_1_1_template_activity.html#afcc0c33eecdce797122c83ac5842357e", null ],
    [ "checkIfExtras", "classcom_1_1example_1_1planertreningow_1_1szablony_1_1_template_activity.html#a9a1fe29458c25d9093e53e79cf7a30c7", null ],
    [ "delete", "classcom_1_1example_1_1planertreningow_1_1szablony_1_1_template_activity.html#adc545a13471ce78d1466b94fd479a931", null ],
    [ "edit", "classcom_1_1example_1_1planertreningow_1_1szablony_1_1_template_activity.html#aff75a63328b2e77fb6017f176f11c678", null ],
    [ "Next", "classcom_1_1example_1_1planertreningow_1_1szablony_1_1_template_activity.html#a09d954c1368b4e0746b7dd649c8cdd73", null ],
    [ "onCreate", "classcom_1_1example_1_1planertreningow_1_1szablony_1_1_template_activity.html#afa5bdbfd2128e1d81dcce9ec95bb6373", null ],
    [ "refreshExerciseList", "classcom_1_1example_1_1planertreningow_1_1szablony_1_1_template_activity.html#acd1a1af7ed9233833b65c8ee50f1ec66", null ],
    [ "Save", "classcom_1_1example_1_1planertreningow_1_1szablony_1_1_template_activity.html#a8bec6628fbd6cf7f7a38bbb93df6304c", null ],
    [ "editing", "classcom_1_1example_1_1planertreningow_1_1szablony_1_1_template_activity.html#a5ca7004dc38e8f9a6ca5c28e4318bb1e", null ],
    [ "imageButton", "classcom_1_1example_1_1planertreningow_1_1szablony_1_1_template_activity.html#a9b770c8e2ab8a85fe6a3dc58c6f3b41b", null ],
    [ "template", "classcom_1_1example_1_1planertreningow_1_1szablony_1_1_template_activity.html#a0514d847d2df0b8774d3b0cc47f6aeff", null ],
    [ "templates", "classcom_1_1example_1_1planertreningow_1_1szablony_1_1_template_activity.html#a468ef8fd7a2007a5c55840a288ac6121", null ],
    [ "trainings", "classcom_1_1example_1_1planertreningow_1_1szablony_1_1_template_activity.html#a85a68892b073e3298f41cf85f8d45997", null ]
];